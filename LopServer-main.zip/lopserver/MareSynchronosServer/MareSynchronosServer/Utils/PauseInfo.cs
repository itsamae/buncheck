﻿namespace MareSynchronosServer.Utils;

public enum PauseInfo
{
    NoConnection,
    Paused,
    Unpaused,
}
