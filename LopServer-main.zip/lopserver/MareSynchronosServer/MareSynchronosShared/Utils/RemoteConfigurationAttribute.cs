﻿namespace MareSynchronosShared.Utils;

[AttributeUsage(AttributeTargets.Property)]
public class RemoteConfigurationAttribute : Attribute { }